package com.shipping.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shipping.bean.Shipping;
import com.shipping.dao.OrderDao;
import com.shipping.exception.OrderException;
@Service
public class OrderServiceImpl implements OrderService {
	@Autowired
	OrderDao orderdao;


	@Override
	public Shipping getOrderById(int id) throws OrderException {
	try
	{
		return orderdao.findById(id).get();
	}
	catch (Exception ex)
	{
		throw new OrderException(ex.getMessage());
	}
	}

	@Override
	public void deleteOrder(int id) throws OrderException {
		try
		{
			orderdao.deleteById(id);
		}
		catch(Exception e)
		{
			throw new OrderException(e.getMessage());
		}
		
	}

	@Override
	public List<Shipping> getAllOrder() throws OrderException {
		try
		{
			return orderdao.findAll();
		}
		catch(Exception e)
		{
			throw new OrderException(e.getMessage());
		}
	}

	@Override
	public List<Shipping> getOrderByCity(String city) throws OrderException {
		// TODO Auto-generated method stub
		try
		{
		return orderdao.getOrderByCity(city);	
		}
		catch(Exception e) {
		throw new OrderException(e.getMessage());
	}
	}

	@Override
	public List<Shipping> updateOrder(int id, Shipping cust) throws OrderException {
		try
		{
			Optional<Shipping> optional=orderdao.findById(id);
			if(optional.isPresent())
			{
				Shipping customer=optional.get();
				customer.setPrice(cust.getPrice());
				customer.setCity(cust.getCity());
				orderdao.save(customer);
				return getAllOrder();
			}
			else
			{
				throw new OrderException("Order with Id"+id+" does not exist");	
			}
		}
			catch(Exception e) {
	            throw new OrderException(e.getMessage());
			}
	}

	@Override
	public Shipping addOrder(Shipping cust) throws OrderException {
		try {
			return orderdao.save(cust);
		}
		catch(Exception e) {
            throw new OrderException(e.getMessage());
		}
	}
}